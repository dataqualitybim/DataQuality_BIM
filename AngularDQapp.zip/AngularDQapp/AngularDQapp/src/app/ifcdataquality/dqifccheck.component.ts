﻿import { Component } from '@angular/core';

@Component({
    selector: 'dqifccheck',
    templateUrl: './dqifccheck.html'
})

export class dqifcCheckComponent {
}

