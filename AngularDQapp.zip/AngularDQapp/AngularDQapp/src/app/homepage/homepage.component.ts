﻿import { Component } from '@angular/core';

@Component({
    selector: 'homepage',
    templateUrl: 'app/homepage/homepage.html',
    styleUrls: ['app/homepage/homepagestyles.css']


})
export class HomePageComponent { }