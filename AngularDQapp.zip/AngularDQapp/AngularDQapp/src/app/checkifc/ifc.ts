﻿export interface Ifc {
    IfcType: string;
    Name: string;
    Tag: string;
    Material: string;
    Breite: DoubleRange;
    }