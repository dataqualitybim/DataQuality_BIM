﻿import { Component } from '@angular/core';

@Component({
    selector: 'dqcheckcost',
    templateUrl: './dqcheckcost.html'
})

export class dqcheckcostComponent {
}

