import { Component } from '@angular/core';

@Component({
    selector: 'my-app',
    templateUrl: './main.html',
    styleUrls: ['./mainstyles.css']
})
export class AppComponent { }
